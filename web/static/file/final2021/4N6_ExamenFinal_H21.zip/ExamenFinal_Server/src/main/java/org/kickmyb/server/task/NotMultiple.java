package org.kickmyb.server.task;

public class NotMultiple extends Exception {

    public NotMultiple (String message){
        super(message);
    }
}
