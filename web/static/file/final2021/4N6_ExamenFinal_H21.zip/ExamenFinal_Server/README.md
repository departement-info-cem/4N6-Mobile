# KickMyB-Server
Spring Boot Server for KickMyB

## Problèmes

Changer de Jav change le format des dates:
https://github.com/google/gson/issues/1210
https://github.com/google/gson/issues/1719

Il faut changer File > Project Structure > 1.8 au lieu de 11 et ça revient à l'ancien format qui marche avec Android
